package com.example.book_management_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
